namespace UnitTests;

public class UnitTest2
{
    const double g = 9.8;
    [Fact]
    public void Test2()
    {
        //Arrange
        double expected = 196;
        double testSpeed2 = 10;
        
        //Act
        double actual = CalcTime(testSpeed2);
        
        //Assert
        Assert.Equal(expected, actual);
    }

    public double CalcTime(double speed)
    {
        return 2 * speed * g;
    }
}