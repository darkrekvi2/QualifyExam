namespace UnitTests;

public class UnitTest1
{
    const double g = 9.8;
    [Fact]
    public void Test1()
    {
        //Arrange
        double expected = 49;
        double testSpeed1 = 2.5;
        
        //Act
        double actual = CalcTime(testSpeed1);
        
        //Assert
        Assert.Equal(expected, actual);
    }

    public double CalcTime(double speed)
    {
        return 2 * speed * g;
    }
}